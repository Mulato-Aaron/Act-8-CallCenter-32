#!/bin/sh
source .venv/bin/activate
python manage.py runserver $PORT
